import Modules from '../components/Modules.jsx';

export default function Home() {
    return (<>
        <Modules />
    </>);
}